﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace Tecan
{

class Program
{
        public class Matrix<T>
        {
            public static string TransposeMatrix(T[][] matrix)
            {
                StringBuilder sb = new StringBuilder();
                int r = matrix[1].GetLength(0);
                int c = matrix.GetLength(0);
                //var result = new T[r, c];
                for (int i = 0; i < r; i++)
                {
                    sb.Append(matrix[0][i]);
                    for (int j = 1; j < c; j++)
                        sb.Append(";" + matrix[j][i]);
                    sb.AppendLine();
                }
                return sb.ToString();
            }

        }
        static bool again = true;

        static void Main(string[] args)
        {
            while (again)
            {

                // Getting file name and directory

                Console.WriteLine("Please enter the file name (*.csv)");
                string workingDirectory = Environment.CurrentDirectory;
                string FileFolder = Directory.GetParent(workingDirectory).Parent.Parent.FullName;
                string FileName = Console.ReadLine();

                // Remove file extention if there is one

                int fileExtPos = FileName.LastIndexOf(".");
                if (fileExtPos >= 0)
                    FileName = FileName.Substring(0, fileExtPos);



                // Find file path in mac and windows. I'm using mac so I haven't tried it yet on Windows

                string FilePath = FileFolder + "/" + FileName + ".csv";
                string FileSave = FileFolder + "/" + FileName + "_transposed.csv";
                if (File.Exists(FilePath) != true) // not in mac, in windows
                {
                    FilePath = FileFolder + "\\" + FileName + ".csv";
                    FileSave = FileFolder + "\\" + FileName + "_transposed.csv";
                }

                // Transposing and saving the file
                try
                { 
                    var matrix = File.ReadAllLines(FilePath).Select(l => l.Split(';').ToArray()).ToArray();
                    var t_matrix = Matrix<string>.TransposeMatrix(matrix);
                    File.WriteAllText(FileSave, t_matrix);
                    Console.WriteLine("\nDone! \n" +
                        "The file has been saved in the following folder:\n" + Directory.GetParent(workingDirectory).Parent.Parent.FullName);
                    again = false;
                }
                catch
                {
                    if(again)
                         Console.WriteLine("File doesn't exist. Please try again\n");
                }
            }

        }
    }
}

